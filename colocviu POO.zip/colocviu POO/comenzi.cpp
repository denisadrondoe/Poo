#include "comenzi.h"

#include <iomanip> //pt setprecision()

// constructorul clasei Comenzi
Comenzi::Comenzi(const string &nume, const vector<pair<string, int>> &comanda)
    : numeClient(nume), numarComenzi(0), pretTotal(0)
{
    for (const auto &produs : comanda)
    { // Iterăm prin comanda pentru a popula lista de produse
        produseComandate.push_back(produs.first);
    }
}

double Comenzi::calculeazaPretTotal(const vector<pair<string, int>> &comanda)
{
    ifstream fisier("meniu.csv");
    if (!fisier.is_open())
    {
        throw runtime_error("Eroare la deschiderea fisierului meniu!"); // exceptie / exceptions
    }

    unordered_map<string, double> preturiMeniu;
    string linie, produs;
    double pret;
    while (getline(fisier, linie))
    {
        stringstream ss(linie);
        getline(ss, produs, ',');
        ss >> pret;
        preturiMeniu[produs] = pret;
    }
    fisier.close(); //inchidefisierul meniu

    double total = 0;
    for (const auto &item : comanda)
    {
        const auto &produs = item.first;
        int cantitate = item.second;
        if (preturiMeniu.find(produs) != preturiMeniu.end())
        {
            total += preturiMeniu[produs] * cantitate;
        }
        else
        {
            cerr << "Produsul" << produs << "nu a fost gasit in meniu." << endl;
        }
    }

    // implementare discount
    ifstream fisierIn("comenzi.csv");
    ofstream fisierOut("comenzi_temp.csv");

    if (!fisierIn.is_open() || !fisierOut.is_open())
    {
        throw runtime_error("Eroare la gestionarea fisierelor CSV!"); // exceptie / exceptions
    }

    string client;
    int numarApariții = 0;    // Variabilă pentru a număra aparițiile clientului
    vector<string> liniiTemp; // Vom salva toate liniile într-un vector temporar

    // Citim fisierul CSV vechi si actualizam informatiile
    while (getline(fisierIn, linie))
    {
        stringstream ss(linie);
        getline(ss, client, ',');

        // Verificăm dacă clientul există și numărăm aparițiile sale
        if (client == numeClient)
        {
            numarApariții++;
        }
        //  salvăm linia în vectorul temporar
        liniiTemp.push_back(linie);
    }

    fisierIn.close(); // aici as vrea in loc sa il inchid sa mut cursorul la inceputul fisierului

    // Dacă clientul a apărut de 3 ori, aplicăm discount-ul
    if (numarApariții == 3)
    {
        total *= 0.9; // Aplicăm reducerea de 10%
        cout << "Felicitari, aveti discount!" << endl;
    }

    // Salvăm comenzile în fișierul temporar
    // Adăugăm comanda clientului la fișierul temporar
    for (const auto &linie : liniiTemp)
    {
        stringstream ss(linie);
        getline(ss, client, ',');
        if (client == numeClient && numarApariții == 3)
        {
            continue;
        }
        else
        {
            fisierOut << linie << endl;
        }
    }

    // Adăugăm comanda curentă la fișier
    fisierOut << numeClient; // Adăugăm numele clientului
    for (const auto &item : comanda)
    {
        fisierOut << "," << item.first << " x" << item.second; // Adăugăm produsele comandate
    }
    fisierOut << "," << total << endl; // Adăugăm totalul

    fisierOut.close(); // Închidem fișierul de scriere

    // Înlocuim fișierul vechi cu fișierul actualizat
    remove("comenzi.csv");
    rename("comenzi_temp.csv", "comenzi.csv");

    // cout << "Pretul total total perntru comanda: ";
    return total;
    
}

void Comenzi::afiseazaMeniu()
{
    ifstream fisier("meniu.csv");
    if (!fisier.is_open())
    {
        cerr << "Eroare la deschiderea fișierului meniu!" << endl;
        return;
    }

    string linie;
    while (getline(fisier, linie))
    {
        cout << linie << endl;
    }

    fisier.close();
}