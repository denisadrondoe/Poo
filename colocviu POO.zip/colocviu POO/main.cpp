#include <iostream>
#include "manager.h"
#include "barista.h"
#include "ospatar.h"
#include "produs.h"
#include "comenzi.h"

#include <iomanip>
#include <memory> // pentru std::unique_ptr
#include <map>

using namespace std;

// template pentru Evenimente Speciale
template <typename T> // template
class EvenimentSpecial
{
public:
    string numeEveniment;
    vector<pair<string, T>> cheltuieli; // Tipul T permite sa folosim orice tip numeric(int, float, double)
    // constructor
    EvenimentSpecial(string nume) : numeEveniment(nume) {} // constructor

    // adauga o cheltuiala
    void adaugaCheltuiala(const string &descriere, T valoare)
    {
        cheltuieli.push_back({descriere, valoare});
    }
    // calculeaza cheltuieli totale
    T calculeazaCheltuieliTotale() const
    {
        T total = 0;
        for (const auto &cheltuiala : cheltuieli)
        {
            total += cheltuiala.second;
        }
        return total;
    }

    // afiseaza detaliile evenimentului
    void afiseazaDetalii() const
    {
        cout << "Eveniment: / Event: " << numeEveniment << endl;
        cout << "Detalii cheltuieli: /Expense details: " << endl;
        for (const auto &cheltuiala : cheltuieli)
        {
            cout << "  - " << cheltuiala.first << ": " << fixed << setprecision(2) << cheltuiala.second << " lei" << endl;
        }
        cout << "Cheltuieli totale: /Total expenses:  " << fixed << setprecision(2) << calculeazaCheltuieliTotale() << " lei" << endl;
    }

    void salveazaInFisier(const string &numeFisier) const
    {
        ofstream fisier(numeFisier, ios::app);
        if (fisier.is_open())
        {
            fisier << "Eveniment: / Event: " << numeEveniment << "\n";
            fisier << "Detalii cheltuieli: /Expense details: \n";
            for (const auto &cheltuiala : cheltuieli)
            {
                fisier << cheltuiala.first << "," << cheltuiala.second << "\n";
            }
            fisier << "Cheltuieli totale: /Total expenses:," << calculeazaCheltuieliTotale() << "\n\n";
            fisier.close();
        }
        else
        {
            cerr << "Eroare la deschiderea fisierului: /Error opening the file " << numeFisier << "\n";
        }
    }

    void introduDateDeLaTastatura()
    {
        int numarCheltuieli;
        cout << "Introduceti numarul de servicii oferite la eveniment /Enter the number of services provided at the event. \n";
        cin >> numarCheltuieli;
        cin.ignore(); // curăță bufferul

        for (int i = 0; i < numarCheltuieli; ++i)
        {
            string descriere;
            T valoare;

            cout << "Cheltuiala /Expense  " << i + 1 << " - descriere/description: ";
            getline(cin, descriere);
            cout << "Cheltuiala /Expense " << i + 1 << " - valoare/value:  ";
            cin >> valoare;
            cin.ignore(); // curăță bufferul

            adaugaCheltuiala(descriere, valoare);
        }
    }
};

// abstractizare, clasa abstracta cu functie pur virtuala
class Cafenea
{
public:
    string nume;

    // Metoda pur virtuala
    virtual void prezentare() const = 0; // Abstractizare

    void salut() const
    {
        cout << "Bine ati venit in orasul " << nume << endl;
        cout << "Veti observa cum decurge o zi la cafeneaua noastra!\n";
    }

    void hello() const
    {
        cout << "Welcome to the city of " << nume << endl;
        cout << "You will observe how a day at our coffee shop unfolds!\n";
    }

    // Destructor virtual
    virtual ~Cafenea() = default;
};

// clasa derivata
class Cafenele : public Cafenea
{ // mostenire
public:
    void prezentare() const override
    {
        cout << "Acesta este un loc unde va puteti bucura de cafea excelenta!" << endl;
    }
};
void meniu()
{ // o zi = rulam odata programul, dupa ce am apasat iesire s-a incheiat ziua
    cout << "Alegeti o optiune:\n";
    cout << "1. Afiseaza toti angajatii din fisier\n";
    cout << "2. Adauga un angajat in fisier\n";
    cout << "3. Sterge un angajat din fisier\n";
    cout << "4. Afiseaza detalii despre un angajat si responsabilitatile acestuia\n";
    cout << "5. Creeaza un Eveniment Special \n"; // aici cream un eveniment special in ziua curenta, ceea ce inseamna ca si acesta va fi adugat la cheltuielile zilnice
    cout << "6. Doresc sa fac o comanda!\n";      // si in asta o sa ii arat si nota de plata dupa ce cumanda
    cout << "7. Adaugare stoc produse\n";
    cout << "8. Iesire\n";
}
void menu() // engleza
{
    cout << "Choose an option:\n";
    cout << "1. Display all employees from the file\n";
    cout << "2. Add an employee to the file\n";
    cout << "3. Delete an employee from the file\n";
    cout << "4. Display details about an employee and their responsibilities\n";
    cout << "5. Create a Special Event\n";   // Here, we create a special event for the current day, which will also be added to the daily expenses
    cout << "6. I want to make an order!\n"; // This will show the bill after the order
    cout << "7. Add stock of products\n";
    cout << "8. Exit\n";
}

// Funcție pentru citirea meniului din CSV
map<string, pair<double, double>> citesteMeniu(const string &fisierCSV)
{
    map<string, pair<double, double>> fmeniu;
    ifstream fisier(fisierCSV);

    if (!fisier.is_open())
    {
        cerr << "Eroare la deschiderea fisierului " << fisierCSV << endl;
        return fmeniu;
    }

    string linie;
    while (getline(fisier, linie))
    {
        stringstream ss(linie);
        string produs, pretClient, pretProducere;

        // Split linie CSV: nume produs, pret client, pret producere
        getline(ss, produs, ',');
        getline(ss, pretClient, ',');
        getline(ss, pretProducere, ',');

        // Adaugă în map
        fmeniu[produs] = {stod(pretClient), stod(pretProducere)};
    }

    fisier.close();
    return fmeniu;
}
int main()
{
    double profit;                  // profitul facut la o comanda
    double costTotal;               // variabila pentru costul total pentru evenimente
    double cheltuieli_totale = 0.0; // pentru salariile angajatilor

    double profitulTotalComenzi = 0.0;      // suma tuturor
    double cheltuieliTotalEvenimente = 0.0; // suma tuturor evenimentelor

    cout << "Choose the language: (E/R)";
    char opp;
    cin >> opp;
    cin.ignore();
    if (opp == 'R')
    {
        Cafenele cafenea; // obiect
        cout << "In ce oras va aflati?(Bucuresti, Timisoara, Iasi, Brasov, Cluj-Napoca)\n";
        getline(cin, cafenea.nume);

        cafenea.salut(); // apelul metodei

        ofstream raportFisier("rapoarte.csv", ios::app); // deschide fisierul in mod append

        string nume_fisier = "angajati.csv";
        Manager manager("Admin", "Manager", "08:00", "14:00", 7000);

        while (true)
        {
            meniu();
            int optiune;
            cin >> optiune;

            if (optiune == 1)
            {
                try
                {
                    cheltuieli_totale = Manager::afiseazaTotiAngajatii("angajati.csv"); // apel static al metodei
                    cout << "Cheltuieli totale cu salariile angajatilor: " << cheltuieli_totale << " RON" << endl;
                }
                catch (const exception &e) // exceptii
                {
                    cerr << "Eroare: " << e.what() << endl;
                }
            }
            else if (optiune == 2)
            {
                string nume, functie, inceput, sfarsit;
                double salariu;
                cout << "Introdu detalii despre angajat: \n";
                cout << "Nume: ";
                cin >> nume;
                cout << "Functie (Barista/Manager/Ospatar): ";
                cin >> functie;
                cout << "Ora inceput: ";
                cin >> inceput;
                cout << "Ora sfarsit: ";
                cin >> sfarsit;
                cout << "Salariu brut: ";
                cin >> salariu;
                try
                {
                    Manager angajat(nume, functie, inceput, sfarsit, salariu); // obiect
                    manager.adaugaAngajat(angajat, nume_fisier);
                    manager.adaugaAngajat(angajat, "employees.csv"); // adaugam si in engleza
                    cout << "Angajatul a fost adaugat cu succes!" << endl;
                }
                catch (const exception &e) // exceptii
                {
                    cerr << "Eroare: " << e.what() << endl;
                }
            }
            else if (optiune == 3)
            {
                string nume_angajat;
                cout << "Introdu numele angajatului pe care doresti sa-l stergi: ";
                cin >> nume_angajat;

                try
                {
                    manager.stergeAngajat(nume_angajat, nume_fisier);
                    manager.stergeAngajat(nume_angajat, "employees.csv"); // stergem si din engleza
                    cout << "Angajatul cu numele \"" << nume_angajat << "\" a fost sters cu succes din fisier." << endl;
                }
                catch (const exception &e)
                {
                    cerr << "Eroare: " << e.what() << endl;
                }
            }
            else if (optiune == 4)
            {
                string nume_angajat;
                cout << "Introdu numele angajatului pentru a-i vedea detaliile si responsabilitatile: ";
                cin >> nume_angajat;

                ifstream fisier(nume_fisier);
                if (!fisier.is_open())
                {
                    cerr << "Eroare la deschiderea fisierului!" << endl;
                    break;
                }

                string linie;
                bool gasit = false;
                while (getline(fisier, linie))
                {
                    stringstream ss(linie);
                    string nume, functie, inceput, sfarsit;
                    double salariu;
                    getline(ss, nume, ',');
                    getline(ss, functie, ',');
                    getline(ss, inceput, ',');
                    getline(ss, sfarsit, ',');
                    ss >> salariu;

                    if (nume == nume_angajat)
                    {
                        gasit = true;
                        if (functie == "Barista")
                        {
                            Barista angajat(nume, inceput, sfarsit, salariu); // obiect
                            angajat.afiseazaDetalii();
                            angajat.descriereResponsabilitati();
                        }
                        else if (functie == "Ospatar")
                        {
                            Ospatar angajat(nume, inceput, sfarsit, salariu);
                            angajat.afiseazaDetalii();
                            angajat.descriereResponsabilitati();
                        }
                        else if (functie == "Manager")
                        {
                            Manager angajat(nume, functie, inceput, sfarsit, salariu); // obiect
                            angajat.afiseazaDetalii();
                            angajat.descriereResponsabilitati();
                        }
                        break;
                    }
                }
                if (!gasit)
                {
                    cout << "Angajatul nu a fost gasit in fisier." << endl;
                }
                fisier.close();
            }
            else if (optiune == 5)
            {
                cout << "Tipurile de evenimente care pot fi organizate in cafenea sunt:" << endl;
                cout << "Degustare de cafea (apasati tasta d pentru aceasta optiune)" << endl;
                cout << "Muzica Live (apasati tasta m pentru aceasta optiune)" << endl;

                char optiune_eveniment;
                cin >> optiune_eveniment;
                cin.ignore();

                costTotal = 0.0;

                if (optiune_eveniment == 'd')
                {
                    // Creare eveniment de degustare cafea
                    EvenimentSpecial<double> degustare("Degustare de Cafea");

                    degustare.introduDateDeLaTastatura();
                    degustare.afiseazaDetalii();
                    degustare.salveazaInFisier("evenimente.csv");

                    costTotal = degustare.calculeazaCheltuieliTotale(); // Calculează costul total
                    cout << "Costul total al evenimentului \"Degustare de Cafea\" este: "
                         << costTotal << " lei" << endl;
                    cout << endl;
                }
                else if (optiune_eveniment == 'm')
                {
                    // Creare eveniment de muzică live
                    EvenimentSpecial<float> muzicaLive("Muzica Live");

                    // Adăugare cheltuieli
                    muzicaLive.introduDateDeLaTastatura();
                    muzicaLive.afiseazaDetalii();
                    muzicaLive.salveazaInFisier("evenimente.csv");

                    costTotal = muzicaLive.calculeazaCheltuieliTotale(); // Calculează costul total
                    cout << "Costul total al evenimentului \"Muzica Live\" este: "
                         << fixed << setprecision(2) << costTotal << " lei" << endl;
                }
                cheltuieliTotalEvenimente += costTotal;
            }
            else if (optiune == 6)
            {
                // Citirea meniului
                const string fisierMeniu = "meniu.csv";
                map<string, pair<double, double>> fmeniu = citesteMeniu(fisierMeniu); // fmeniu = fisier_meniu

                if (fmeniu.empty())
                {
                    cout << "Meniul nu a putut fi incarcat." << endl;
                    return 1;
                }

                vector<pair<string, int>> comanda; // va stoca produsele comandate și cantitățile
                string numeClient;
                cout << "Ce doriti sa comandati? Introduceti numele clientului: ";
                cin.ignore();
                getline(cin, numeClient);

                // Afisezi meniul pentru clienti
                Comenzi::afiseazaMeniu(); // metoda statica

                int nrProduse; // cate tipuri de produse
                cout << "Cate produse doriti sa comandati? / How many products would you like to order? ";
                cin >> nrProduse;
                cin.ignore(); // curăță buffer-ul după număr pentru a permite getline să funcționeze corect

                double costTotalComanda = 0.0;
                double costTotalProducere = 0.0;

                profit = 0.0;

                // Interacționezi cu clientul și înregistrezi comanda
                for (int i = 0; i < nrProduse; i++)
                {
                    string produs;
                    int cantitate;

                    cout << "Introduceti produsul dorit (de exemplu: caffe latte): ";

                    getline(cin, produs);

                    // if (produs == "gata")
                    //     break; // clientul a terminat comanda

                    cout << "Introduceti cantitatea: ";
                    cin >> cantitate;
                    cin.ignore(); // pentru a curăța buffer-ul

                    unique_ptr<PreparaBautura> bautura; // Obiectul de tip PreparaBautura

                    // Crearea obiectelor de băuturi în funcție de produsul ales
                    if (produs == "espresso")
                    {
                        bautura = make_unique<PreparaEspresso>("Espresso", 1, 5.0); // Nume, cantitate, preț
                    }
                    else if (produs == "espresso dublu")
                    {
                        bautura = make_unique<PreparaEspressoDublu>("Espresso Dublu", 1, 5.0); // Nume, cantitate, preț
                    }
                    else if (produs == "caffe latte")
                    {
                        bautura = make_unique<PreparaCaffeLatte>("CaffeLatte", 1, 5.0); // Nume, cantitate, preț
                    }
                    else if (produs == "cappuccino")
                    {
                        bautura = make_unique<PreparaCappuccino>("Cappuccino", 1, 5.0); // Nume, cantitate, preț
                    }
                    else if (produs == "flat white")
                    {
                        bautura = make_unique<PreparaFlatWhite>("FlatWhite", 1, 5.0); // Nume, cantitate, preț
                    }
                    else if (produs == "ceai de menta")
                    {
                        bautura = make_unique<PreparaCeaiDeMenta>("CeaiDeMenta", 1, 5.0); // Nume, cantitate, preț
                    }
                    else if (produs == "ceai de musetel")
                    {
                        bautura = make_unique<PreparaCeaiDeMusetel>("CeaiDeMusetel", 1, 5.0); // Nume, cantitate, preț
                    }
                    else if (produs == "ceai de fructe")
                    {
                        bautura = make_unique<PreparaCeaiDeFructe>("CeaiDeFructe", 1, 5.0); // Nume, cantitate, preț
                    }
                    else if (produs == "ciocolata calda")
                    {
                        bautura = make_unique<PreparaCiocolataCalda>("CiocolataCalda", 1, 5.0); // Nume, cantitate, preț
                    }
                    else if (produs == "limonada")
                    {
                        bautura = make_unique<PreparaLimonada>("Limonada", 1, 5.0); // Nume, cantitate, preț
                    }
                    else if (produs == "fresh portocale")
                    {
                        bautura = make_unique<PreparaFreshPortocale>("FreshPortocale", 1, 5.0); // Nume, cantitate, preț
                    }

                    try
                    {
                        // Verifică dacă obiectul a fost creat
                        if (bautura)
                        {
                            // Apelarea metodei de preparare
                            bautura->prepara(); // Template method care va apela adaugaIngrediente() din PreparaEspresso
                        }
                        else
                        {
                            cout << "Produsul nu este valid pentru preparare!" << endl;
                        }

                        // Verifică dacă produsul este în meniu si calculam costul pentru a produce aceasta comanda
                        if (fmeniu.find(produs) != fmeniu.end())
                        {
                            double pretClient = fmeniu[produs].first;
                            double pretProducere = fmeniu[produs].second;

                            // costTotalComanda += pretClient * cantitate;
                            costTotalProducere += pretProducere * cantitate;

                            comanda.emplace_back(produs, cantitate);
                        }
                        else
                        {
                            cout << "Produsul \"" << produs << "\" nu exista in meniu!" << endl;
                        }
                    }
                    catch (const runtime_error &e)
                    {
                        cout << "Eroare la prepararea produsului: " << e.what() << endl;
                        continue; // Continuă cu următorul produs
                    }
                }
                // acum folosim metoda din clasa comenzi prentru a calcula costulTotalProducere(si cu discount daca este cazul)
                try
                {
                    // Creează obiectul comenzii
                    Comenzi comandaClient(numeClient, comanda);

                    costTotalComanda = comandaClient.calculeazaPretTotal(comanda);
                    cout << "Nota de plata este: " << costTotalComanda << endl;
                }
                catch (const exception &e) // exceptie
                {
                    cout << "Eroare: " << e.what() << endl;
                }
                // nota de plata + costuri totale
                // Afișează totalurile
                // cout << "Nota de plata (cost total comanda): " << costTotalComanda << " lei" << endl;
                cout << "Cost total producere comanda: " << costTotalProducere << " lei" << endl;

                profit = costTotalComanda - costTotalProducere;
                cout << "Profitul realizat pentru aceasta comanda este: " << profit << " lei" << endl;

                profitulTotalComenzi += profit;
            }
            else if (optiune == 7)
            {
                string numeProdus;
                int cantitate;
                double pretProdus = 0;

                // adaugare produse in stoc
                cout << "Suplimentati stocul pentru produse! \n";
                cout << "Nume produs: ";
                cin.ignore();
                getline(cin, numeProdus);

                cout << "Introduceti cantitatea pe care doriti sa o adaugati: ";
                cin >> cantitate;

                // Creează un obiect Produs pentru a apela metoda
                Produs produs("", 0, 0); // Obiect temporar

                // Întreabă prețul doar dacă produsul nu există
                if (!produs.adaugaProdusInStoc(numeProdus, cantitate, pretProdus))
                {
                    cout << "Produsul nu exista. Introduceti pretul produsului: ";
                    cin >> pretProdus;
                    produs.adaugaProdusInStoc(numeProdus, cantitate, pretProdus);
                }

                cout << "Stocul a fost actualizat cu succes!" << endl;
            }
            else if (optiune == 8)
            {
                cout << "Iesire din aplicatie. La revedere!\n";
                break;
            }
            else
            {
                cout << "Optiune invalida. Incearca din nou.\n";
            }

            // manager = 7000  6h  08:00 - 14:00
            // barista = 6000 8h 08:00 - 16:00 240 Ron/zi
            // chelner = 5000 8h 08:00 - 16:00  200 Ron/zi
            // barista = 5000 6h 16:00 - 22:00  200 Ron/zi
            // chelner = 4000 6h 16:00 - 22:00  160 Ron/zi
        }

        // dupa ce se incheie, noi trebuie sa generam un raport detaliat despre: venituri, costuri, salarii , profit
        // raportare finala
        double profitFinal = profitulTotalComenzi - cheltuieliTotalEvenimente - cheltuieli_totale;

        cout << "Raportarea zilnica:" << endl;
        cout << "Profitul total realizat din comenzi este: " << profitulTotalComenzi << endl;
        cout << "Cheltuielile prentru evenimente: " << cheltuieliTotalEvenimente << endl;
        cout << "Cheltuielile pentru plata salriilor: " << cheltuieli_totale << endl;
        cout << endl;
        cout << "Raportul final intre incasari si profit este: " << profitFinal << endl;

        if (raportFisier.is_open())
        {
            // scriem datele in fisier
            raportFisier << profitulTotalComenzi << ","
                         << cheltuieliTotalEvenimente << ","
                         << cheltuieli_totale << ","
                         << profitFinal << "\n"; // adăugare date raport

            raportFisier.close(); // închide fișierul
            cout << "Raportul a fost salvat in 'rapoarte.csv'.\n";
        }
        else
        {
            cerr << "Eroare la deschiderea fisierului raparte.csv" << endl;
        }
    }
    else if (opp == 'E')
    {
        Cafenele cafenea;
        cout << "Which city are you in? (Bucharest, Timisoara, Iasi, Brasov, Cluj-Napoca)\n";
        getline(cin, cafenea.nume);

        cafenea.hello();

        ofstream raportFisier("rapoarte.csv", ios::app); // open the file in append mode

        string nume_fisier = "employees.csv";
        Manager manager("Admin", "Manager", "08:00", "14:00", 7000);

        while (true)
        {
            menu();
            int optiune;
            cin >> optiune;

            if (optiune == 1)
            {
                try
                {
                    cheltuieli_totale = Manager::afiseazaTotiAngajatii("employees.csv");
                    cout << "Total employee salary expenses: " << cheltuieli_totale << " RON" << endl;
                }
                catch (const exception &e)
                {
                    cerr << "Error: " << e.what() << endl;
                }
            }
            else if (optiune == 2)
            {
                string nume, functie, inceput, sfarsit;
                double salariu;
                cout << "Enter employee details: \n";
                cout << "Name: ";
                cin >> nume;
                cout << "Position (Barista/Manager/Waiter): ";
                cin >> functie;
                cout << "Start time: ";
                cin >> inceput;
                cout << "End time: ";
                cin >> sfarsit;
                cout << "Gross salary: ";
                cin >> salariu;
                try
                {
                    Manager angajat(nume, functie, inceput, sfarsit, salariu);
                    manager.adaugaAngajat(angajat, "angajati.csv"); // il adaugam si in fisierul in romana
                    manager.adaugaAngajat(angajat, "employees.csv");
                    cout << "The employee has been successfully added!" << endl;
                }
                catch (const exception &e)
                {
                    cerr << "Error: " << e.what() << endl;
                }
            }
            else if (optiune == 3)
            {
                string nume_angajat;
                cout << "Enter the name of the employee you want to delete: ";
                cin >> nume_angajat;

                try
                {
                    manager.stergeAngajat(nume_angajat, nume_fisier);
                    manager.stergeAngajat(nume_angajat, "angajati.csv"); // trebuie sa il stergem si din fisierul in romana
                    cout << "The employee with the name \"" << nume_angajat << "\" has been successfully removed from the file." << endl;
                }
                catch (const exception &e)
                {
                    cerr << "Error: " << e.what() << endl;
                }
            }
            else if (optiune == 4)
            {
                string nume_angajat;
                cout << "Enter the name of the employee to see their details and responsibilities: ";
                cin >> nume_angajat;

                ifstream fisier(nume_fisier);
                if (!fisier.is_open())
                {
                    cerr << "Error opening file!" << endl;
                    break;
                }

                string linie;
                bool gasit = false;
                while (getline(fisier, linie))
                {
                    stringstream ss(linie);
                    string nume, functie, inceput, sfarsit;
                    double salariu;
                    getline(ss, nume, ',');
                    getline(ss, functie, ',');
                    getline(ss, inceput, ',');
                    getline(ss, sfarsit, ',');
                    ss >> salariu;

                    if (nume == nume_angajat)
                    {
                        gasit = true;
                        if (functie == "Barista")
                        {
                            Barista angajat(nume, inceput, sfarsit, salariu);
                            angajat.afiseazaDetalii();
                            angajat.descriereResponsabilitati();
                        }
                        else if (functie == "Waiter")
                        {
                            Ospatar angajat(nume, inceput, sfarsit, salariu);
                            angajat.afiseazaDetalii();
                            angajat.descriereResponsabilitati();
                        }
                        else if (functie == "Manager")
                        {
                            Manager angajat(nume, functie, inceput, sfarsit, salariu);
                            angajat.afiseazaDetalii();
                            angajat.descriereResponsabilitati();
                        }
                        break;
                    }
                }
                if (!gasit)
                {
                    cout << "Employee not found in the file." << endl;
                }
                fisier.close();
            }
            else if (optiune == 5)
            {
                cout << "The types of events that can be organized in the cafe are:" << endl;
                cout << "Coffee Tasting (press d for this option)" << endl;
                cout << "Live Music (press m for this option)" << endl;

                char optiune_eveniment;
                cin >> optiune_eveniment;
                cin.ignore();

                costTotal = 0.0;

                if (optiune_eveniment == 'd')
                {
                    // Create coffee tasting event
                    EvenimentSpecial<double> degustare("Coffee Tasting");

                    degustare.introduDateDeLaTastatura();
                    degustare.afiseazaDetalii();
                    degustare.salveazaInFisier("evenimente.csv");

                    costTotal = degustare.calculeazaCheltuieliTotale(); // Calculate total cost
                    cout << "The total cost of the \"Coffee Tasting\" event is: "
                         << fixed << setprecision(2) << costTotal << " RON" << endl;
                    cout << endl;
                }
                else if (optiune_eveniment == 'm')
                {
                    // Create live music event
                    EvenimentSpecial<float> muzicaLive("Live Music");

                    // Add expenses
                    muzicaLive.introduDateDeLaTastatura();
                    muzicaLive.afiseazaDetalii();
                    muzicaLive.salveazaInFisier("evenimente.csv");

                    costTotal = muzicaLive.calculeazaCheltuieliTotale(); // Calculate total cost
                    cout << "The total cost of the \"Live Music\" event is: "
                         << fixed << setprecision(2) << costTotal << " RON" << endl;
                }
                cheltuieliTotalEvenimente += costTotal;
            }
            else if (optiune == 6)
            {
                // Citirea meniului
                const string fisierMeniu = "meniu.csv";
                map<string, pair<double, double>> fmeniu = citesteMeniu(fisierMeniu); // fmeniu = fisier_meniu

                if (fmeniu.empty())
                {
                    cout << "The menu could not be loaded." << endl;
                    return 1;
                }

                vector<pair<string, int>> comanda; // va stoca produsele comandate și cantitățile
                string numeClient;
                cout << "What would you like to order? Enter the customer's name:";
                cin.ignore();
                getline(cin, numeClient);

                // Afisezi meniul pentru clienti
                Comenzi::afiseazaMeniu();

                int nrProduse; // cate tipuri de produse
                cout << "How many products would you like to order? ";
                cin >> nrProduse;
                cin.ignore(); // curăță buffer-ul după număr pentru a permite getline să funcționeze corect

                double costTotalComanda = 0.0;
                double costTotalProducere = 0.0;
                profit = 0.0;

                // Interacționezi cu clientul și înregistrezi comanda
                for (int i = 0; i < nrProduse; i++)
                {
                    string produs;
                    int cantitate;

                    cout << "Enter the desired product (for example: caffe latte):";

                    getline(cin, produs);

                    // if (produs == "gata")
                    //     break; // clientul a terminat comanda

                    cout << "Enter the quantity: ";
                    cin >> cantitate;
                    cin.ignore(); // pentru a curăța buffer-ul

                    unique_ptr<PreparaBautura> bautura; // Obiectul de tip PreparaBautura

                    // Verifică dacă produsul este espresso și creează obiectul corespunzător
                    if (produs == "espresso")
                    {
                        bautura = make_unique<PreparaEspresso>("Espresso", 1, 5.0); // Nume, cantitate, preț
                    }
                    else if (produs == "double espresso")
                    {
                        bautura = make_unique<PreparaEspressoDublu>("Espresso Dublu", 1, 5.0); // Nume, cantitate, preț
                    }
                    else if (produs == "caffe latte")
                    {
                        bautura = make_unique<PreparaCaffeLatte>("CaffeLatte", 1, 5.0); // Nume, cantitate, preț
                    }
                    else if (produs == "cappuccino")
                    {
                        bautura = make_unique<PreparaCappuccino>("Cappuccino", 1, 5.0); // Nume, cantitate, preț
                    }
                    else if (produs == "flat white")
                    {
                        bautura = make_unique<PreparaFlatWhite>("FlatWhite", 1, 5.0); // Nume, cantitate, preț
                    }
                    else if (produs == "mint tea")
                    {
                        bautura = make_unique<PreparaCeaiDeMenta>("CeaiDeMenta", 1, 5.0); // Nume, cantitate, preț
                    }
                    else if (produs == "chamomile tea")
                    {
                        bautura = make_unique<PreparaCeaiDeMusetel>("CeaiDeMusetel", 1, 5.0); // Nume, cantitate, preț
                    }
                    else if (produs == "fruit tea")
                    {
                        bautura = make_unique<PreparaCeaiDeFructe>("CeaiDeFructe", 1, 5.0); // Nume, cantitate, preț
                    }
                    else if (produs == "hot chocolate")
                    {
                        bautura = make_unique<PreparaCiocolataCalda>("CiocolataCalda", 1, 5.0); // Nume, cantitate, preț
                    }
                    else if (produs == "lemonade")
                    {
                        bautura = make_unique<PreparaLimonada>("Limonada", 1, 5.0); // Nume, cantitate, preț
                    }
                    else if (produs == "orange fresh juice")
                    {
                        bautura = make_unique<PreparaFreshPortocale>("FreshPortocale", 1, 5.0); // Nume, cantitate, preț
                    }
                    try
                    {
                        // Verifică dacă obiectul a fost creat
                        if (bautura)
                        {
                            // Apelarea metodei de preparare
                            bautura->prepara(); // Template method care va apela adaugaIngrediente() din PreparaEspresso
                        }
                        else
                        {
                            cout << "The product is not valid for preparation!" << endl;
                        }

                        // Verifică dacă produsul este în meniu si calculam costul pentru a produce aceasta comanda
                        if (fmeniu.find(produs) != fmeniu.end())
                        {
                            double pretClient = fmeniu[produs].first;
                            double pretProducere = fmeniu[produs].second;

                            // costTotalComanda += pretClient * cantitate;
                            costTotalProducere += pretProducere * cantitate;

                            comanda.emplace_back(produs, cantitate);
                        }
                        else
                        {
                            cout << "The product \"" << produs << "\" it's not on the menu!" << endl;
                        }
                    }
                    catch (const runtime_error &e)
                    {
                        cout << "Error while preparing the product: " << e.what() << endl;
                        costTotalComanda = 0.0;
                        costTotalProducere = 0.0;
                        profit = 0.0;
                        continue; // Continuă cu următorul produs
                    }
                }
                // acum folosim metoda din clasa comenzi prentru a calcula costulTotalProducere(si cu discount daca este cazul)
                try
                {
                    // Creează obiectul comenzii
                    Comenzi comandaClient(numeClient, comanda);

                    costTotalComanda = comandaClient.calculeazaPretTotal(comanda);
                    cout << "The bill is: " << costTotalComanda << endl;
                }
                catch (const exception &e)
                {
                    cout << "Error: " << e.what() << endl;
                }
                // nota de plata + costuri totale
                // Afișează totalurile
                // cout << "Nota de plata (cost total comanda): " << costTotalComanda << " lei" << endl;
                cout << "Total production cost of the order: " << costTotalProducere << " lei" << endl;

                profit = costTotalComanda - costTotalProducere;
                cout << "The profit made for this order is: " << profit << " lei" << endl;

                profitulTotalComenzi += profit;
            }
            else if (optiune == 7)
            {
                string numeProdus;
                int cantitate;
                double pretProdus = 0;

                // adding products to stock
                cout << "Add product to stock: \n";
                cout << "Product name: ";
                cin.ignore();
                getline(cin, numeProdus);

                cout << "Enter the quantity you want to add: ";
                cin >> cantitate;

                // Create a Produs object to call the method
                Produs produs("", 0, 0); // Temporary object

                // Ask for the price only if the product doesn't exist
                // Întreabă prețul doar dacă produsul nu există
                if (!produs.adaugaProdusInStoc(numeProdus, cantitate, pretProdus))
                {
                    cout << "The product does not exist. Enter the product price:";
                    cin >> pretProdus;
                    produs.adaugaProdusInStoc(numeProdus, cantitate, pretProdus);
                }
                cout << "The stock has been updated successfully!" << endl;
            }
            else if (optiune == 8)
            {
                cout << "Goodbye!" << endl;
                break;
            }
            else
            {
                cout << "Invalid option!" << endl;
            }
            // manager = 7000  6h  08:00 - 14:00  300 Ron/zi
            // barista = 6000 8h 08:00 - 16:00 240 Ron/zi
            // chelner = 5000 8h 08:00 - 16:00  200 Ron/zi
            // barista = 5000 6h 16:00 - 22:00  200 Ron/zi
            // chelner = 4000 6h 16:00 - 22:00  160 Ron/zi
        }

        double profitFinal = profitulTotalComenzi - cheltuieliTotalEvenimente - cheltuieli_totale;

        cout << "Daily Report:" << endl;
        cout << "Total profit from orders: " << profitulTotalComenzi << endl;
        cout << "Expenses for events: " << cheltuieliTotalEvenimente << endl;
        cout << "Expenses for salary payments: " << cheltuieli_totale << endl;
        cout << endl;
        cout << "The final report between income and profit is: " << profitFinal << endl;

        if (raportFisier.is_open())
        {
            // scriem datele in fisier
            raportFisier << profitulTotalComenzi << ","
                         << cheltuieliTotalEvenimente << ","
                         << cheltuieli_totale << ","
                         << profitFinal << "\n"; // adăugare date raport

            raportFisier.close(); // închide fișierul
            cout << "The report has been saved in 'rapoarte.csv'.\n";
        }
        else
        {
            cerr << "Error opening the file rapoarte.csv" << endl;
        }
    }

    return 0;
}
