#ifndef BARISTA_H
#define BARISTA_H

#include "angajat.h" //deoarece mosteneste clasa angajat

class Barista : public Angajat  // mostenire
{
public:
    // constructor
    Barista(string n, string inceput, string sfarsit, double salariu);

    virtual void afiseazaDetalii() const override; //polimorfism : Suprascrierea metodei afiseazaDetalii din clasa de baza
    virtual void descriereResponsabilitati() const override; //polimorfism
};

#endif
