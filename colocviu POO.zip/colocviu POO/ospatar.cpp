#include "ospatar.h"

// Constructor
Ospatar::Ospatar(string n, string inceput, string sfarsit, double salariu)
    : Angajat(n, "Ospatar", inceput, sfarsit, salariu) {}

// Suprascrierea metodei afiseazaDetalii polimorfism
void Ospatar::afiseazaDetalii() const {
    cout << "Ospatar:/Waiter: " << nume << endl;
    cout << "Program:/Schedule: " << program_inceput << " - " << program_sfarsit << endl;
    cout << "Salariu net:/ Net salary:" << salariu_net << endl;
}

// Implementarea responsabilitatilor polimorfism
void Ospatar::descriereResponsabilitati() const {
    cout << "Serveste clientii si asigura o experienta placuta./";
    cout << "Serves customers and ensures a pleasant experience."<<endl;
}