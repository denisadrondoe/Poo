#ifndef OSPATAR_H
#define OSPATAR_H

#include "angajat.h" //deoarece mosteneste clasa angajat

class Ospatar : public Angajat  //mostenire
{
public:
    // constructor
    Ospatar(string n, string inceput, string sfarsit, double salariu);

    virtual void afiseazaDetalii() const override; // polimorfism
    virtual void descriereResponsabilitati() const override; // polimorfism

};

#endif
