#ifndef COMENZI_H
#define COMENZI_H

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <string>
#include <vector>
#include <unordered_map>
#include <iomanip>

using namespace std;

class Comenzi
{
private:  //incapsulare
    string numeClient;
    int numarComenzi;
    vector<string> produseComandate;
    double pretTotal;
    // double costProductie;
public:
// constructor
    Comenzi(const string &nume, const vector<pair<string, int>> &comanda);
    
    double calculeazaPretTotal(const vector<pair<string, int>> &comanda);
    static void afiseazaMeniu();
};

#endif