#include "produs.h"

// constructor 
Produs::Produs(const string& n, int c, double p) : nume(n), cantitate(c), pret(p) {}

//incapsulare
string Produs::getNume() const {
    return nume;
}

int Produs::getCantitate() const {
    return cantitate;
}

double Produs::getPret() const {
    return pret;
}

bool Produs::consumaProdus(const string& numeProdus, int cantitateConsumata) {
    ifstream fisierIn("produse.csv");
    ofstream fisierOut("produse_temp.csv"); // Fișier temporar pentru actualizare
    bool produsGasit = false;

    if (!fisierIn.is_open() || !fisierOut.is_open()) {
        cout << "Eroare la deschiderea fisierului CSV!" << endl;
        return false;
    }

    string linie;
    while (getline(fisierIn, linie)) {
        stringstream ss(linie);
        string produs, cantitateStr, pretStr;
        getline(ss, produs, ',');
        getline(ss, cantitateStr, ',');
        getline(ss, pretStr, ',');

        int cantitateDisponibila = stoi(cantitateStr);
        double pret = stod(pretStr);

        if (produs == numeProdus) {
            produsGasit = true;
            if (cantitateDisponibila >= cantitateConsumata) {
                cantitateDisponibila -= cantitateConsumata;
                cout << "Produsul " << produs << " a fost consumat: " << cantitateConsumata << " buc." << endl;
            } else {
                throw runtime_error("Stoc insuficient pentru produsul: " + produs);
                return false;
            }
        }

        fisierOut << produs << "," << cantitateDisponibila << "," << pret << endl;
    }

    fisierIn.close();
    fisierOut.close();

    // Ștergerea fișierului original și redenumirea fișierului temporar
    if (produsGasit) {
        remove("produse.csv");
        rename("produse_temp.csv", "produse.csv");
    } else {
        remove("produse_temp.csv"); // Dacă produsul nu a fost găsit, ștergi fișierul temporar
        cout << "Produsul " << numeProdus << " nu a fost gasit în fisierul CSV." << endl;
        return false;
    }

    return true;
}

double Produs::calculeazaCost(const string& numeProdus, int cantitateNecesară) {
    ifstream fisierIn("produse.csv");

    if (!fisierIn.is_open()) {
        cout << "Eroare la deschiderea fisierului CSV!" << endl;
        return 0;
    }

    string linie;
    while (getline(fisierIn, linie)) {
        stringstream ss(linie);
        string produs, cantitateStr, pretStr;
        getline(ss, produs, ',');
        getline(ss, cantitateStr, ',');
        getline(ss, pretStr, ',');

        int cantitateDisponibila = stoi(cantitateStr);
        double pret = stod(pretStr);

        if (produs == numeProdus) {
            if (cantitateNecesară <= cantitateDisponibila) {
                return pret * cantitateNecesară;
            } else {
                cout << "Stoc insuficient pentru produsul: " << produs << endl;
                return 0;
            }
        }
    }

    cout << "Produsul " << numeProdus << " nu a fost gasit in fisierul CSV." << endl;
    return 0;
}

bool Produs::esteDisponibil(int cantitate_necesara) const {
    return cantitate >= cantitate_necesara;
}

void Produs::afiseazaProdus() const {
    cout << nume << ", " << cantitate << "buc, pret: " << pret << " RON" << endl;
}

// Adaugă produs în stoc sau actualizează stocul pentru un produs existent
bool Produs::adaugaProdusInStoc(const string& numeProdus, int cantitate, double pret) {
    ifstream fisierIn("produse.csv");
    ofstream fisierOut("produse_temp.csv"); // Fișier temporar pentru actualizare
    bool produsGasit = false;

    if (!fisierIn.is_open() || !fisierOut.is_open()) {
        cout << "Eroare la deschiderea fisierului CSV!" << endl;
        return false;
    }

    string linie;
    while (getline(fisierIn, linie)) {
        stringstream ss(linie);
        string produs, cantitateStr, pretStr;
        getline(ss, produs, ',');
        getline(ss, cantitateStr, ',');
        getline(ss, pretStr, ',');

        int cantitateDisponibila = stoi(cantitateStr); 
        double pretExist = stod(pretStr);

        if (produs == numeProdus) { //produsul a fost gasit in fisier 
            produsGasit = true;
            cantitateDisponibila += cantitate; // Actualizează cantitatea
            fisierOut << produs << "," << cantitateDisponibila << "," << pretExist << endl;
        } else {
            fisierOut << produs << "," << cantitateDisponibila << "," << pretExist << endl; //daca nu coincid, ramane la fel 
        }
    }

    if (!produsGasit) {
        // Dacă produsul nu există, il adaugam cu numele, cantitate, și pret
        fisierOut << numeProdus << "," << cantitate << "," << pret << endl;
    }

    fisierIn.close();
    fisierOut.close();

    remove("produse.csv");
    rename("produse_temp.csv", "produse.csv");
    return true;
}
// Constructorul clasei PreparaBautura
PreparaBautura::PreparaBautura(const string& n, int c, double p) : Produs(n, c, p) {
    // Poți adăuga orice logică suplimentară pentru PreparaBautura, dacă este necesar
}

// Implementarea metodelor pentru clasele derivate (template method Design Patterns)
void PreparaBautura::prepara() {
    fierbeApa();
    adaugaIngrediente();
    toarnaInCeasca();
    servește();
}
//abstractizare + template method
void PreparaBautura::fierbeApa() {
    cout << "Pregatim apa..." << endl;
}

void PreparaBautura::toarnaInCeasca() {
    cout << "Turnat in recipient..." << endl;
}

void PreparaBautura::servește() {
    cout << "Servire bautura..." << endl;
}

//destructor
PreparaBautura::~PreparaBautura() {}

//constructor  
PreparaEspresso::PreparaEspresso(const string &n, int c, double p) : PreparaBautura(n, c, p) {}

// Clasele derivate pentru băuturi   polimorfism
void PreparaEspresso::adaugaIngrediente() {
    if (consumaProdus("cafea", 1) && consumaProdus("zahar", 1)) {
        double cost = calculeazaCost("cafea", 1) + calculeazaCost("zahar", 1);
        cout << "Adaugare cafea si zahar pentru Espresso..." << endl;
        cout << "Cost productie: " << cost << " lei" << endl;
    } else {
        cout << "Ingrediente insuficiente pentru Espresso!" << endl;
    }
}
PreparaEspressoDublu::PreparaEspressoDublu(const string &n, int c, double p) : PreparaBautura(n, c, p) {}
void PreparaEspressoDublu::adaugaIngrediente() {
    if (consumaProdus("cafea", 2) && consumaProdus("zahar", 1)) {
        double cost = calculeazaCost("cafea", 2) + calculeazaCost("zahar", 1);
        cout << "Adaugare cafea si zahar pentru Espresso Dublu..." << endl;
        cout << "Cost productie: " << cost << " lei" << endl;
    } else {
        cout << "Ingrediente insuficiente pentru Espresso Dublu!" << endl;
    }
}

PreparaCaffeLatte::PreparaCaffeLatte(const string &n, int c, double p) : PreparaBautura(n, c, p) {}
void PreparaCaffeLatte::adaugaIngrediente() {
    if (consumaProdus("cafea", 1) && consumaProdus("lapte", 2)) {
        double cost = calculeazaCost("cafea", 1) + calculeazaCost("lapte", 2);
        cout << "Adaugare cafea si lapte pentru Caffe Latte..." << endl;
        cout << "Cost productie: " << cost << " lei" << endl;
    } else {
        cout << "Ingrediente insuficiente pentru Caffe Latte!" << endl;
    }
}
PreparaCappuccino::PreparaCappuccino(const string &n, int c, double p) : PreparaBautura(n, c, p) {}
void PreparaCappuccino::adaugaIngrediente() {
    if (consumaProdus("cafea", 1) && consumaProdus("lapte", 2)) {
        double cost = calculeazaCost("cafea", 1) + calculeazaCost("lapte", 2);
        cout << "Adaugare cafea si lapte pentru Cappuccino..." << endl;
        cout << "Cost productie: " << cost << " lei" << endl;
    } else {
        cout << "Ingrediente insuficiente pentru Cappuccino!" << endl;
    }
}

PreparaFlatWhite::PreparaFlatWhite(const string &n, int c, double p) : PreparaBautura(n, c, p) {}
void PreparaFlatWhite::adaugaIngrediente() {
    if (consumaProdus("cafea", 2) && consumaProdus("lapte", 1)) {
        double cost = calculeazaCost("cafea", 1) + calculeazaCost("lapte", 2);
        cout << "Adaugare cafea si lapte pentru Flat White..." << endl;
        cout << "Cost productie: " << cost << " lei" << endl;
    } else {
        cout << "Ingrediente insuficiente pentru Flat White!" << endl;
    }
}

PreparaCeaiDeMusetel::PreparaCeaiDeMusetel(const string &n, int c, double p) : PreparaBautura(n, c, p) {}
void PreparaCeaiDeMusetel::adaugaIngrediente() {
    if (consumaProdus("ceai de musetel", 2) && consumaProdus("zahar", 1)) {
        double cost = calculeazaCost("ceai de musetel", 2) + calculeazaCost("zahar", 1);
        cout << "Adaugare musetel si zahar pentru Ceai de musetel..." << endl;
        cout << "Cost productie: " << cost << " lei" << endl;
    } else {
        cout << "Ingrediente insuficiente pentru Ceai de Musetel!" << endl;
    }
}

PreparaCeaiDeMenta::PreparaCeaiDeMenta(const string &n, int c, double p) : PreparaBautura(n, c, p) {}
void PreparaCeaiDeMenta::adaugaIngrediente() {
    if (consumaProdus("ceai de menta", 2) && consumaProdus("zahar", 1)) {
        double cost = calculeazaCost("ceai de menta", 2) + calculeazaCost("zahar", 1);
        cout << "Adaugare menta si zahar pentru Ceai de Menta..." << endl;
        cout << "Cost productie: " << cost << " lei" << endl;
    } else {
        cout << "Ingrediente insuficiente pentru Ceai de Menta!" << endl;
    }
}

PreparaCeaiDeFructe::PreparaCeaiDeFructe(const string &n, int c, double p) : PreparaBautura(n, c, p) {}
void PreparaCeaiDeFructe::adaugaIngrediente() {
    if (consumaProdus("ceai de fructe", 2) && consumaProdus("zahar", 1)) {
        double cost = calculeazaCost("ceai de fructe", 2) + calculeazaCost("zahar", 1);
        cout << "Adaugare fructe si zahar pentru Ceai de fructe..." << endl;
        cout << "Cost productie: " << cost << " lei" << endl;
    } else {
        cout << "Ingrediente insuficiente pentru Ceai de Fructe!" << endl;
    }
}

PreparaCiocolataCalda::PreparaCiocolataCalda(const string &n, int c, double p) : PreparaBautura(n, c, p) {}
void PreparaCiocolataCalda::adaugaIngrediente() {
    if (consumaProdus("ciocolata", 1) && consumaProdus("lapte", 2)) {
        double cost = calculeazaCost("lapte", 2) + calculeazaCost("ciocolata", 1);
        cout << "Adaugare ciocolata si lapte pentru Ciocolata Calda..." << endl;
        cout << "Cost productie: " << cost << " lei" << endl;
    } else {
        cout << "Ingrediente insuficiente pentru Ciocolata Calda!" << endl;
    }
}

PreparaLimonada::PreparaLimonada(const string &n, int c, double p) : PreparaBautura(n, c, p) {}
void PreparaLimonada::adaugaIngrediente() {
    if (consumaProdus("lamaie", 1) && consumaProdus("apa", 2) && consumaProdus("zahar", 2)) {
        double cost = calculeazaCost("zahar", 2) + calculeazaCost("lamaie", 1) + calculeazaCost("apa", 2);
        cout << "Adaugare zeama de lamaie, apa si zahar pentru Limonada..." << endl;
        cout << "Cost productie: " << cost << " lei" << endl;
    } else {
        cout << "Ingrediente insuficiente pentru Limonada!" << endl;
    }
}

PreparaFreshPortocale::PreparaFreshPortocale(const string &n, int c, double p) : PreparaBautura(n, c, p) {}
void PreparaFreshPortocale::adaugaIngrediente() {
    if (consumaProdus("portocala", 1) && consumaProdus("apa", 2) && consumaProdus("zahar", 2)) {
        double cost = calculeazaCost("zahar", 2) + calculeazaCost("portocala", 1) + calculeazaCost("apa", 2);
        cout << "Adaugare zeama de portocala, apa si zahar pentru Fresh Portocale..." << endl;
        cout << "Cost productie: " << cost << " lei" << endl;
    } else {
        cout << "Ingrediente insuficiente pentru Fresh Portocale!" << endl;
    }
}
