#include "manager.h"

// constructor
Manager::Manager(string n, string functie, string inceput, string sfarsit, double salariu)
    : Angajat(n, functie, inceput, sfarsit, salariu) {}

// Suprascrierea metodei afiseazaDetalii : polimorfism
void Manager::afiseazaDetalii() const
{
    cout << "Manager: /Manager " << nume << endl;
    cout << "Program: /Schedule: " << program_inceput << " - " << program_sfarsit << endl;
    cout << "Salariu net: /Net salary:  " << salariu_net << endl;
}

// Implementarea responsabilităților : polimorfism
void Manager::descriereResponsabilitati() const
{
    cout << "Coordoneaza echipa, gestioneaza resursele si rezolva problemele./ ";
    cout << "Coordinates the team, manages resources, and solves problems."<<endl;
}

// folosim <vector> prentru a stoca angajatii(sa ii putem accesa mai tarziu)
double Manager::afiseazaTotiAngajatii(const string &nume_fisier)
{
    ifstream fisier(nume_fisier);
    if (!fisier.is_open())
    {
        throw runtime_error("Nu s-a putut deschide fisierul pentru citire!"); //exceptie
    }

    double cheltuieli_totale = 0;

    string linie;
    while (getline(fisier, linie))
    {
        stringstream ss(linie);
        string nume, functie, program_inceput, program_sfarsit;
        double salariu_brut;

        // Citim fiecare câmp din fișier
        getline(ss, nume, ',');
        getline(ss, functie, ',');
        getline(ss, program_inceput, ',');
        getline(ss, program_sfarsit, ',');
        ss >> salariu_brut;

        // Creăm un obiect Angajat și apelăm funcția de afișare
        Angajat angajat(nume, functie, program_inceput, program_sfarsit, salariu_brut);
        angajat.afiseazaDetalii(); //// Apelul explicit la metoda din clasa de bază

        // Calculăm salariul zilnic în funcție de program și funcție
        if (functie == "Manager")
        {
            cheltuieli_totale += 300; // Manager - 300 RON/zi
        }
        else if (functie == "Barista")
        {
            if (program_inceput == "08:00" && program_sfarsit == "16:00")
            {
                cheltuieli_totale += 240; // Barista 8h - 240 RON/zi
            }
            else if (program_inceput == "16:00" && program_sfarsit == "22:00")
            {
                cheltuieli_totale += 200; // Barista 6h - 200 RON/zi
            }
        }
        else if (functie == "Ospatar" || functie == "Waiter")
        {
            if (program_inceput == "08:00" && program_sfarsit == "16:00")
            {
                cheltuieli_totale += 200; // Chelner 8h - 200 RON/zi
            }
            else if (program_inceput == "16:00" && program_sfarsit == "22:00")
            {
                cheltuieli_totale += 160; // Chelner 6h - 160 RON/zi
            }
        }
    }
    fisier.close();
    return cheltuieli_totale;
}
// adaugarea unui angajat in fisierul CSV
void Manager::adaugaAngajat(const Angajat &angajat, const string &nume_fisier)
{
    ofstream fisier(nume_fisier, ios::app); // deschidem fisierul in mod append
    if (!fisier.is_open())
    {
        throw runtime_error("Nu s-a putut deschide fisierul! /The file could not be opened!");
    }
    fisier << angajat.getNume() << ","
           << angajat.getFunctie() << ","
           << angajat.getProgramInceput() << ","
           << angajat.getProgramSfarsit() << ","
           << angajat.getSalariuBrut() << endl;
    ;

    fisier.close();
}

// stergerea unui angajat din fisierul CSV
void Manager::stergeAngajat(const string &nume_angajat, const string &nume_fisier)
{
    ifstream fisier(nume_fisier);
    if (!fisier.is_open())
    {
        throw runtime_error("Nu s-a putut deschide fisierul angajat.csv/ The file employee.csv could not be opened!"); //exceptie
    }

    vector<Angajat> angajati;
    string linie;
    bool gasit = false; // Flag pentru verificarea existenței numelui în fișier

    while (getline(fisier, linie))
    {
        stringstream ss(linie);
        string nume, functie, program_inceput, program_sfarsit;
        double salariu_brut;

        getline(ss, nume, ',');
        getline(ss, functie, ',');
        getline(ss, program_inceput, ',');
        getline(ss, program_sfarsit, ',');
        ss >> salariu_brut;

        if (nume != nume_angajat)
        { // Dacă nu este angajatul pe care dorim să-l ștergem
            angajati.push_back(Manager(nume, functie, program_inceput, program_sfarsit, salariu_brut));
        }
        else
        {
            gasit = true; // marcam numele ca gasit in fisier
            continue;
        }
    }

    fisier.close();

    // Dacă numele nu a fost găsit, afișăm un mesaj și ieșim din funcție
    if (!gasit)
    {
        throw runtime_error("Angajatul cu acest nume nu a fost gasit in fisier./The employee with this name was not found in the file.");
        
    }

    // Rescrierea fișierului cu angajații rămași
    ofstream fisier_out(nume_fisier);
    if (!fisier_out.is_open())
    {
        cerr << "Nu s-a putut deschide fisierul !/ The file could not be opened!" << endl;
        return;
    }

    for (const auto &angajat : angajati)
    {
        fisier_out << angajat.getNume() << ","
                   << angajat.getFunctie() << ","
                   << angajat.getProgramInceput() << ","
                   << angajat.getProgramSfarsit() << ","
                   << angajat.getSalariuBrut() << endl;
    }

    fisier_out.close();

}