#ifndef PRODUS_H
#define PRODUS_H

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>

using namespace std;

class Produs //clasa produs
{
private: //incapsulare 
    string nume;
    int cantitate;
    double pret;

public:
// constructor 
    Produs(const string &n, int c, double p);

    string getNume() const;
    int getCantitate() const;
    double getPret() const;
    bool consumaProdus(const string &numeProdus, int cantitateConsumata);
    double calculeazaCost(const string &numeProdus, int cantitateNecesară);
    bool esteDisponibil(int cantitate_necesara) const;
    void afiseazaProdus() const;

    // Permite adăugarea unui produs în stoc fără a crea o instanță a clasei.
    static bool adaugaProdusInStoc(const string &numeProdus, int cantitate, double pret);
};
// abstractizare su mostenire
class PreparaBautura : public Produs
{
public:
    PreparaBautura(const string &n, int c, double p);
    // Template Method Design Pattern : definirea structurii genreale a unui proces, lasand detaliile pentru clase derivate 
    void prepara();

// abstractizare :metoda pur virtuala
    virtual void adaugaIngrediente() = 0; // Metoda pur virtuala (abstractizare)
    void fierbeApa();
    void toarnaInCeasca();
    void servește();

// destructor
    virtual ~PreparaBautura();
};

// Definirea claselor derivate pentru fiecare tip de băutură
class PreparaEspresso : public PreparaBautura
{
public:
    PreparaEspresso(const string &n, int c, double p);
    void adaugaIngrediente() override;
};

class PreparaEspressoDublu : public PreparaBautura
{
public:
    PreparaEspressoDublu(const string &n, int c, double p);
    void adaugaIngrediente() override;
};

class PreparaCaffeLatte : public PreparaBautura
{
public:
    PreparaCaffeLatte(const string &n, int c, double p);
    void adaugaIngrediente() override;
};

class PreparaCappuccino : public PreparaBautura
{
public:
    PreparaCappuccino(const string &n, int c, double p);
    void adaugaIngrediente() override;
};

class PreparaFlatWhite : public PreparaBautura
{
public:
    PreparaFlatWhite(const string &n, int c, double p);
    void adaugaIngrediente() override;
};

class PreparaCeaiDeMusetel : public PreparaBautura
{
public:
    PreparaCeaiDeMusetel(const string &n, int c, double p);
    void adaugaIngrediente() override;
};

class PreparaCeaiDeMenta : public PreparaBautura
{
public:
    PreparaCeaiDeMenta(const string &n, int c, double p);
    void adaugaIngrediente() override;
};

class PreparaCeaiDeFructe : public PreparaBautura
{
public:
    PreparaCeaiDeFructe(const string &n, int c, double p);
    void adaugaIngrediente() override;
};

class PreparaCiocolataCalda : public PreparaBautura
{
public:
    PreparaCiocolataCalda(const string &n, int c, double p);
    void adaugaIngrediente() override;
};

class PreparaLimonada : public PreparaBautura
{
public:
    PreparaLimonada(const string &n, int c, double p);
    void adaugaIngrediente() override;
};

class PreparaFreshPortocale : public PreparaBautura
{
public:
    PreparaFreshPortocale(const string &n, int c, double p);
    void adaugaIngrediente() override;
};

#endif // PRODUS_H
