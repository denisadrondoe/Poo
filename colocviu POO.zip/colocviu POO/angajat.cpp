#include "angajat.h"

// Constructor
Angajat::Angajat(string n, string f, string inceput, string sfarsit, double salariu)
    : nume(n), functie(f), program_inceput(inceput), program_sfarsit(sfarsit), salariu_brut(salariu), salariu_net(0)
{
    calculeazaSalariuNet();
}

string Angajat::getNume() const
{
    return nume; 
}

void Angajat::setNume(const string &n)
{
    nume = n; 
}

// getter si setter pentru functie
string Angajat::getFunctie() const
{
    return functie;
}

void Angajat::setFunctie(const string &f)
{
    functie = f;
}

string Angajat::getProgramInceput() const
{
    return program_inceput;
}

void Angajat::setProgramInceput(const string &inceput)
{
    program_inceput = inceput;
}

string Angajat::getProgramSfarsit() const
{
    return program_sfarsit;
}

void Angajat::setProgramSfarsit(const string &sfarsit)
{
    program_sfarsit = sfarsit;
}

// getter si setter prentru salariu
double Angajat::getSalariuBrut() const
{
    return salariu_brut;
}

void Angajat::setSalariuBrut(double salariu)
{
    salariu_brut = salariu;
    calculeazaSalariuNet(); //aici imi calculeaza salariul net 
}

double Angajat::getSalariuNet() const
{
    return salariu_net;
}

// Calculează salariul net pe baza unui impozit de 10%  
// polimorfism
void Angajat::calculeazaSalariuNet()
{
    // Calcularea contribuțiilor și impozitelor
    double impozit_venit = salariu_brut * 0.10; // 10% impozit pe venit
    double cas = salariu_brut * 0.25;           // 25% CAS
    double cass = salariu_brut * 0.10;          // 10% CASS

    // Calculul salariului net
    salariu_net = salariu_brut - impozit_venit - cas - cass;
}

// metoda pentru afisarea datelor despre angajat
// polimorfism 
void Angajat::afiseazaDetalii() const
{
    cout <<  nume << " | " <<  functie << " | " << program_inceput << " - " << program_sfarsit << " | "
         << salariu_brut << " RON | " << salariu_net << " RON." << endl;
}

// polimorfism
void Angajat::descriereResponsabilitati() const
{
    cout<<"sa fie responsabil";
}
