#ifndef ANGAJAT_H
#define ANGAJAT_H

#include <string>
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <stdexcept>

using namespace std;

class Angajat {  // Clasa 
    protected:
    string nume; 
    string functie;  //(Barista, Manager, Ospatar)
    string program_inceput;  // Ora de inceput a turei
    string program_sfarsit;  // Ora de sfârsit a turei
    double salariu_brut;
    double salariu_net;  //calculam pe baza unui preocent de impozitare 

    public:
    // Constructor 
    Angajat(string n, string f, string inceput, string sfarsit, double salariu);

    string getNume() const;
    void setNume(const string& n);

    string getFunctie() const;
    void setFunctie(const string& f);

    string getProgramInceput() const;
    void setProgramInceput(const string& inceput);

    string getProgramSfarsit() const;
    void setProgramSfarsit(const string& sfarsit);

    //getter si setter pentru salariu 
    double getSalariuBrut() const;
    void setSalariuBrut(double salariu);

    double getSalariuNet() const;
    void calculeazaSalariuNet();

    virtual void afiseazaDetalii() const; //polimorfism 

    virtual void descriereResponsabilitati() const;
};

#endif
