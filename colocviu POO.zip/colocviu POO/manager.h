#ifndef MANAGER_H
#define MANAGER_H

#include "angajat.h" //deoarece mosteneste clasa angajat

class Manager : public Angajat  //mostenire
{
public:
    // constructor
    Manager(string n, string functie, string inceput, string sfarsit, double salariu);
    
    // polimorfism
    virtual void afiseazaDetalii() const override;
    virtual void descriereResponsabilitati() const override;

    //afisam toti angajatii din csv
    static double afiseazaTotiAngajatii(const string& nume_fisier);
    
    // Funcții pentru citirea și manipularea fișierelor
    void adaugaAngajat(const Angajat& angajat, const string& nume_fisier);
    void stergeAngajat(const string& nume_angajat, const string& nume_fisier);

};

#endif
