#include "barista.h"

// constructor
Barista::Barista(string n, string inceput, string sfarsit, double salariu)
    : Angajat(n, "Barista", inceput, sfarsit, salariu) {}

// polimorfism : suprascriem metoda afiseazaDetalii
void Barista::afiseazaDetalii() const
{
    cout << "Barista:/Barista: " << nume << endl;
    cout << "Program:/Schedule: " << program_inceput << " - " << program_sfarsit << endl;
    cout << "Salariu net:/Net salary: " << salariu_net << endl;
}

//implementare responsabilitati : polimorfism
void Barista::descriereResponsabilitati() const {
    cout << "Pregateste bauturi, mentine curatenia zonei de lucru.";
    cout << "Prepares drinks, maintains cleanliness of the workspace."<<endl;
}